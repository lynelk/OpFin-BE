<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">Users</h3>
        <?php if(Auth::user()->role === 'Admin'): ?>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i> Add User
            </a>
        <?php endif; ?>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Institution</th>
                            <th>Phone</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td>
                                    <div class="fw-bold"><?php echo e($user->name); ?></div>
                                    <small class="text-muted"><?php echo e($user->email ?? 'N/A'); ?></small>
                                </td>
                                <td><?php echo e($user->institution->name ?? 'N/A'); ?></td>
                                <td><?php echo e($user->phone ?? 'N/A'); ?></td>
                                <td>
                                    <?php echo e($user->role); ?>

                                </td>
                                <td><span class="badge bg-success">Active</span></td>
                                <td><?php echo e($user->created_at?->format('M d, Y')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                        class="btn btn-sm btn-outline-secondary">Edit</a>
                                    <a href="<?php echo e(route('users.show', $user)); ?>" class="btn btn-sm btn-outline-primary">
                                        View
                                    </a>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No users found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/users/index.blade.php ENDPATH**/ ?>