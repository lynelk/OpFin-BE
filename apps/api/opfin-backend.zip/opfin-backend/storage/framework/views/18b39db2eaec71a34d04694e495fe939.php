<?php $__env->startSection('title', 'Institutions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">Institutions</h3>
        <?php if(Auth::user()->role === 'Super'): ?>
            <a href="<?php echo e(route('institutions.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i> Add Institution
            </a>
        <?php endif; ?>
    </div>

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Institution List</strong>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($institution->id); ?></td>
                                <td><?php echo e($institution->name); ?></td>
                                <td><?php echo e($institution->phone); ?></td>
                                <td><?php echo e($institution->email); ?></td>
                                <td><?php echo e($institution->address); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($institution->status === 'Active' ? 'bg-success' : 'bg-secondary'); ?> text-white">
                                        <?php echo e($institution->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($institution->created_at?->format('M d, Y')); ?></td>
                                <td><?php echo e($institution->updated_at?->format('M d, Y')); ?></td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a href="<?php echo e(route('institutions.edit', $institution->id)); ?>"
                                            class="btn btn-sm btn-outline-primary" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form action="<?php echo e(route('institutions.destroy', $institution->id)); ?>" method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this institution?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No institutions found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/institutions/index.blade.php ENDPATH**/ ?>