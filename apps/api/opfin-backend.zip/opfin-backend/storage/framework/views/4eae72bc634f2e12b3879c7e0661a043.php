<?php $__env->startSection('title', 'Edit Loan Product Term'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">Edit Loan Product Term</h3>
        <a href="<?php echo e(route('loan-products.show', $loanProduct->id)); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Back
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Term Details</strong>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('loan-products.update-term', [$loanProduct->id, $term->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="interest_rate" class="form-label">Interest Rate (%) <span
                                class="text-danger">*</span></label>
                        <input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['interest_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="interest_rate"
                            name="interest_rate" value="<?php echo e(old('interest_rate', $term->interest_rate)); ?>" required>
                        <?php $__errorArgs = ['interest_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="interest_type" class="form-label">Interest Type <span
                                class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['interest_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="interest_type"
                            name="interest_type" required>
                            <option value="Flat"
                                <?php echo e(old('interest_type', $term->interest_type) == 'Flat' ? 'selected' : ''); ?>>Flat</option>
                            <option value="Amortization"
                                <?php echo e(old('interest_type', $term->interest_type) == 'Amortization' ? 'selected' : ''); ?>>
                                Amortization
                            </option>
                        </select>
                        <?php $__errorArgs = ['interest_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="interest_cycle" class="form-label">Interest Cycle <span
                                class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['interest_cycle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="interest_cycle"
                            name="interest_cycle" required>
                            <option value="Daily"
                                <?php echo e(old('interest_cycle', $term->interest_cycle) == 'Daily' ? 'selected' : ''); ?>>Daily
                            </option>
                            <option value="Weekly"
                                <?php echo e(old('interest_cycle', $term->interest_cycle) == 'Weekly' ? 'selected' : ''); ?>>Weekly
                            </option>
                            <option value="Monthly"
                                <?php echo e(old('interest_cycle', $term->interest_cycle) == 'Monthly' ? 'selected' : ''); ?>>Monthly
                            </option>
                        </select>
                        <?php $__errorArgs = ['interest_cycle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="repayment_frequency" class="form-label">Repayment Frequency <span
                                class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['repayment_frequency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="repayment_frequency" name="repayment_frequency" required>
                            <option value="Daily"
                                <?php echo e(old('repayment_frequency', $term->repayment_frequency) == 'Daily' ? 'selected' : ''); ?>>
                                Daily</option>
                            <option value="Weekly"
                                <?php echo e(old('repayment_frequency', $term->repayment_frequency) == 'Weekly' ? 'selected' : ''); ?>>
                                Weekly</option>
                            <option value="Monthly"
                                <?php echo e(old('repayment_frequency', $term->repayment_frequency) == 'Monthly' ? 'selected' : ''); ?>>
                                Monthly</option>
                        </select>
                        <?php $__errorArgs = ['repayment_frequency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="duration" class="form-label">Duration (in days) <span
                                class="text-danger">*</span></label>
                        <input type="number" class="form-control <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="duration"
                            name="duration" value="<?php echo e(old('duration', $term->duration)); ?>" required>
                        <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status"
                            required>
                            <option value="Active" <?php echo e(old('status', $term->status) == 'Active' ? 'selected' : ''); ?>>Active
                            </option>
                            <option value="Inactive" <?php echo e(old('status', $term->status) == 'Inactive' ? 'selected' : ''); ?>>
                                Inactive</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-check-circle me-1"></i> Update Term
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/loan-products/edit-term.blade.php ENDPATH**/ ?>