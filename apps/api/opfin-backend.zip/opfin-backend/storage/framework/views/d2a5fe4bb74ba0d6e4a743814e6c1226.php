<?php $__env->startSection('title', 'Loan Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0"><?php echo e($loanProduct->name); ?></h3>
        <a href="<?php echo e(route('loan-products.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Back
        </a>
    </div>

    <div class="card shadow-sm mb-5">
        <div class="card-header">
            <strong>Product Details</strong>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Name:</strong>
                            <span><?php echo e($loanProduct->name); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Type:</strong>
                            <span><?php echo e($loanProduct->type); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Portfolio Balance:</strong>
                            <span><?php echo e($loanProduct->account?->balance ?? 'N/A'); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Institution:</strong>
                            <span><?php echo e($loanProduct->institution?->name ?? 'N/A'); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Status:</strong>
                            <span class="badge <?php if($loanProduct->status == 'Active'): ?> bg-success <?php else: ?> bg-secondary <?php endif; ?>">
                                <?php echo e($loanProduct->status); ?>

                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Created At:</strong>
                            <span><?php echo e($loanProduct->created_at?->format('M d, Y')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <strong>Updated At:</strong>
                            <span><?php echo e($loanProduct->updated_at?->format('M d, Y')); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong>Product Terms</strong>
            <a href="<?php echo e(route('loan-products.add-term', $loanProduct->id)); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i> Add Term
            </a>
        </div>

        <div class="card-body">
            <?php if($loanProduct->terms->isEmpty()): ?>
                <p class="text-muted mb-0">No terms available for this product.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Interest Rate</th>
                                <th>Interest Type</th>
                                <th>Interest Cycle</th>
                                <th>Repayment Frequency</th>
                                <th>Duration</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loanProduct->terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($term->interest_rate); ?>%</td>
                                    <td><?php echo e($term->interest_type); ?></td>
                                    <td><?php echo e($term->interest_cycle); ?></td>
                                    <td><?php echo e($term->repayment_frequency); ?></td>
                                    <td><?php echo e($term->duration); ?> days</td>
                                    <td>
                                        <span
                                            class="badge <?php echo e($term->status === 'Active' ? 'bg-success' : 'bg-secondary'); ?>">
                                            <?php echo e($term->status); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('loan-products.edit-term', [$loanProduct->id, $term->id])); ?>"
                                            class="btn btn-sm btn-outline-primary me-1">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form
                                            action="<?php echo e(route('loan-products.change-term-status', [$loanProduct->id, $term->id])); ?>"
                                            method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit"
                                                class="btn btn-sm btn-<?php echo e($term->status == 'Active' ? 'outline-secondary' : 'outline-success'); ?>"
                                                onclick="return confirm('Are you sure you want to update the status of this term?')">
                                                <i class="bi <?php echo e($term->status == 'Active' ? 'bi-pause' : 'bi-play'); ?>"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/loan-products/show.blade.php ENDPATH**/ ?>