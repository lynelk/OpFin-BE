<?php $__env->startSection('title', 'SMS Messages'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0"><?php echo e($status ?? ''); ?> SMS Messages</h3>
    </div>

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>SMS Log</strong>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Recipient</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Sent At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $smsMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($sms->id); ?></td>
                                <td><?php echo e($sms->to); ?></td>
                                <td class="text-truncate" style="max-width: 300px;" title="<?php echo e($sms->message); ?>">
                                    <?php echo e(Str::limit($sms->message, 50)); ?>

                                </td>
                                <td>
                                    <span
                                        class="badge bg-<?php echo e($sms->status == 'Pending' ? 'secondary' : ($sms->status == 'Failed' ? 'danger' : 'success')); ?>">
                                        <?php echo e($sms->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($sms->created_at->format('M d, Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No SMS messages found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($smsMessages->hasPages()): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($smsMessages->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/sms-messages/index.blade.php ENDPATH**/ ?>