<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0"> <?php echo e($status ?? ''); ?> Transactions</h3>
        <a href="#" class="btn btn-outline-primary">
            <i class="bi bi-download me-1"></i> Export
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header">
            <strong>Transaction List</strong>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Phone</th>
                            <th>User</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Network</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($transaction->id); ?></td>
                                <td><?php echo e($transaction->user->phone); ?></td>
                                <td><?php echo e($transaction->user->name ?? 'N/A'); ?></td>
                                <td><?php echo e($transaction->type); ?></td>
                                <td><?php echo e(number_format($transaction->amount, 2)); ?></td>
                                <td><?php echo e($transaction->network); ?></td>
                                <td><small class="text-muted"><?php echo e($transaction->data); ?></small></td>
                                <td>
                                    <span
                                        class="badge bg-<?php echo e($transaction->status == 'PENDING'
                                            ? 'secondary'
                                            : ($transaction->status == 'SUCCESSFUL'
                                                ? 'success'
                                                : ($transaction->status == 'FAILED'
                                                    ? 'danger'
                                                    : 'info'))); ?>">
                                        <?php echo e($transaction->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($transaction->created_at->format('M d, Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No transactions found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($transactions->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/transactions/index.blade.php ENDPATH**/ ?>