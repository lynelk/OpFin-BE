<?php $__env->startSection('title', 'Loan Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">Loan Products</h3>
        <a href="<?php echo e(route('loan-products.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i> Add Loan Product
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Portfolio</th>
                            <th>Institution</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $loanProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->type); ?></td>
                                <td><?php echo e($product->account?->balance); ?></td>
                                <td><?php echo e($product->institution?->name ?? 'N/A'); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($product->status === 'Active' ? 'bg-success' : 'bg-secondary'); ?> text-white">
                                        <?php echo e($product->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($product->created_at?->format('M d, Y')); ?></td>
                                <td><?php echo e($product->updated_at?->format('M d, Y')); ?></td>
                                <td class="d-flex gap-1">
                                    <a href="<?php echo e(route('loan-products.show', $product->id)); ?>"
                                        class="btn btn-sm btn-outline-primary" title="View">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('loan-products.edit', $product->id)); ?>"
                                        class="btn btn-sm btn-outline-warning" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('loan-products.change-status', $product->id)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to update the status of this product?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit"
                                            class="btn btn-sm btn-outline-<?php echo e($product->status === 'Active' ? 'secondary' : 'success'); ?>"
                                            title="<?php echo e($product->status === 'Active' ? 'Deactivate' : 'Activate'); ?>">
                                            <i
                                                class="bi <?php echo e($product->status === 'Active' ? 'bi-x-circle' : 'bi-check-circle'); ?>"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No loan products found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/loan-products/index.blade.php ENDPATH**/ ?>