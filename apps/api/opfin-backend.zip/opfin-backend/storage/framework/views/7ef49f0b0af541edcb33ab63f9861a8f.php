<?php $__env->startSection('title', 'Loan Applications'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0"><?php echo e($status ?? ''); ?> Loan Applications</h3>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Institution</th>
                            <th>Loan Product</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Applied At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($application->id); ?></td>
                                <td><?php echo e($application->user->name ?? 'N/A'); ?></td>
                                <td><?php echo e($application->institution->name ?? 'N/A'); ?></td>
                                <td><?php echo e($application->loanProduct->name ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($application->amount, 2)); ?></td>
                                <td>
                                    <span
                                        class="badge bg-<?php echo e($application->status == 'Pending'
                                            ? 'secondary'
                                            : ($application->status == 'Disbursed'
                                                ? 'success'
                                                : ($application->status == 'Rejected'
                                                    ? 'danger'
                                                    : 'info'))); ?>">
                                        <?php echo e($application->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($application->created_at?->format('M d, Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No loan applications found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($applications->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/loan-applications/index.blade.php ENDPATH**/ ?>