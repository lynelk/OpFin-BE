<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Admin Panel</title>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body class="d-flex" style="min-height:100vh;">
    
    <div class="sidebar d-flex flex-column p-3">
        <h5 class="mb-4">
            <a href="<?php echo e(url('/')); ?>" class="text-white text-decoration-none">Loan System</a>
        </h5>

        <?php if(auth()->guard()->check()): ?>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(request()->is('home*') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                        <i class="bi bi-people me-2"></i> Users
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#"
                        class="nav-link dropdown-toggle <?php echo e(request()->is('loan-applications*') ? 'active' : ''); ?>"
                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-file-earmark-text me-2"></i> Applications
                    </a>

                    <ul class="dropdown-menu sidebar-dropdown">
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('loan-applications/disbursed') ? 'active' : ''); ?>"
                                href="<?php echo e(route('loan-applications.index', ['status' => 'Disbursed'])); ?>">
                                Disbursed
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('loan-applications/rejected') ? 'active' : ''); ?>"
                                href="<?php echo e(route('loan-applications.index', ['status' => 'Rejected'])); ?>">
                                Rejected
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('loan-products.index')); ?>"
                        class="nav-link <?php echo e(request()->is('loan-products*') ? 'active' : ''); ?>">
                        <i class="bi bi-cash-coin me-2"></i> Loan Products
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle <?php echo e(request()->is('loans*') ? 'active' : ''); ?>"
                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-wallet2 me-2"></i> Loans
                    </a>

                    <ul class="dropdown-menu sidebar-dropdown">
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('loans/disbursed') ? 'active' : ''); ?>"
                                href="<?php echo e(route('loans.index', ['status' => 'Disbursed'])); ?>">
                                Disbursed
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('loans/cleared') ? 'active' : ''); ?>"
                                href="<?php echo e(route('loans.index', ['status' => 'Cleared'])); ?>">
                                Cleared
                            </a>
                        </li>
                    </ul>
                </li>


                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle <?php echo e(request()->is('transactions*') ? 'active' : ''); ?>"
                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-arrow-left-right me-2"></i> Transactions
                    </a>

                    <ul class="dropdown-menu sidebar-dropdown">
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('transactions/successful') ? 'active' : ''); ?>"
                                href="<?php echo e(route('transactions.index', ['status' => 'Successful'])); ?>">
                                Successful
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('transactions/pending') ? 'active' : ''); ?>"
                                href="<?php echo e(route('transactions.index', ['status' => 'Pending'])); ?>">
                                Pending
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item <?php echo e(request()->is('transactions/failed') ? 'active' : ''); ?>"
                                href="<?php echo e(route('transactions.index', ['status' => 'Failed'])); ?>">
                                Failed
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('accounts.index')); ?>"
                        class="nav-link <?php echo e(request()->is('accounts*') ? 'active' : ''); ?>">
                        <i class="bi bi-bank me-2"></i> Accounts
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('chat.index')); ?>" class="nav-link <?php echo e(request()->is('chats*') ? 'active' : ''); ?>">
                        <i class="bi bi-chat-dots me-2"></i> Chat
                    </a>
                </li>

                

                <?php if(Auth::user()->role == 'Super'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('institutions.index')); ?>"
                            class="nav-link <?php echo e(request()->is('institutions*') ? 'active' : ''); ?>">
                            <i class="bi bi-buildings me-2"></i> Institutions
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a href="#"
                            class="nav-link dropdown-toggle <?php echo e(request()->is('sms-messages*') ? 'active' : ''); ?>"
                            role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-chat-left-text me-2"></i> SMS Messages
                        </a>

                        <ul class="dropdown-menu sidebar-dropdown">
                            <li>
                                <a class="dropdown-item <?php echo e(request()->is('sms-messages/sent') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('sms-messages.index', ['status' => 'Sent'])); ?>">
                                    Sent
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php echo e(request()->is('sms-messages/pending') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('sms-messages.index', ['status' => 'Pending'])); ?>">
                                    Pending
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php echo e(request()->is('sms-messages/failed') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('sms-messages.index', ['status' => 'Failed'])); ?>">
                                    Failed
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        <?php endif; ?>
    </div>

    
    <div class="main-content d-flex flex-column flex-grow-1" style="min-height:100vh;">
        
        <div class="topbar px-4 py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><?php echo $__env->yieldContent('title'); ?></h5>
            <?php if(auth()->guard()->check()): ?>
                <div class="dropdown">
                    <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle"
                        id="userDropdown" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-2"></i>
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#">Profile</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item" type="submit">Logout</button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="container-fluid py-4 px-4 d-flex flex-column flex-grow-1"> <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/layouts/app.blade.php ENDPATH**/ ?>