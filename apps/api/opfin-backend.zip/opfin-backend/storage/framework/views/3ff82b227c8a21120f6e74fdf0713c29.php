<?php $__env->startSection('title', 'View User'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0"><?php echo e($user->name); ?></h3>
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left me-1"></i> Back to Users
        </a>
    </div>

    <?php if($latestScore): ?>
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Credit Score</span>
                <small class="text-muted">
                    Fetched <?php echo e($latestScore->created_at->diffForHumans()); ?>

                </small>
            </div>

            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-3">
                        <h4 class="fw-bold"><?php echo e($latestScore->score); ?></h4>
                        <small class="text-muted">Score</small>
                    </div>

                    <div class="col-md-3">
                        <h4><?php echo e($latestScore->band); ?></h4>
                        <small class="text-muted">Band</small>
                    </div>

                    <div class="col-md-3">
                        <span class="badge bg-<?php echo e($latestScore->rating === 'Very Poor' ? 'danger' : 'success'); ?>">
                            <h5><?php echo e($latestScore->rating); ?></h5>
                        </span> <br>
                        <small class="text-muted">Rating</small>
                    </div>

                    <div class="col-md-3">
                        <h4><?php echo e($latestScore->probability_of_default_percent); ?>%</h4>
                        <small class="text-muted">Default Probability</small>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            No credit score found for this user.
        </div>
    <?php endif; ?>
    <?php if($scoreHistory->count()): ?>
        <div class="card">
            <div class="card-header">
                <button class="btn btn-link p-0" data-bs-toggle="collapse" data-bs-target="#creditHistory">
                    View Credit Score History
                </button>
            </div>

            <div id="creditHistory" class="collapse">
                <div class="card-body p-0">
                    <table class="table mb-0 table-sm">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Score</th>
                                <th>Band</th>
                                <th>Rating</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $scoreHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($score->created_at->format('d M Y')); ?></td>
                                    <td><?php echo e($score->score); ?></td>
                                    <td><?php echo e($score->band); ?></td>
                                    <td><?php echo e($score->rating); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/users/show.blade.php ENDPATH**/ ?>