<?php $__env->startSection('title', 'Loans'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0"><?php echo e($status ?? ''); ?> Loans</h3>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Loan Product</th>
                            <th>Amount</th>
                            <th>Repayment</th>
                            <th>Outstanding</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Disbursed At</th>
                            <th>Repayment Start Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loan->id); ?></td>
                                <td><?php echo e($loan->user->name ?? 'N/A'); ?></td>
                                <td><?php echo e($loan->loanProduct->name ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($loan->amount)); ?></td>
                                <td><?php echo e(number_format($loan->repayment_amount)); ?></td>
                                <td><?php echo e(number_format($loan->outstanding_balance)); ?></td>
                                <td><?php echo e($loan->duration); ?> days</td>
                                <td>
                                    <span
                                        class="badge bg-<?php echo e($loan->status == 'Disbursed' ? 'secondary' : ($loan->status == 'Cleared' ? 'success' : 'info')); ?>">
                                        <?php echo e($loan->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($loan->disbursed_at->format('M d, Y H:i')); ?></td>
                                <td><?php echo e($loan->repayment_start_date->format('M d, Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-1"></i> No loans found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($loans->hasPages()): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($loans->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/loans/index.blade.php ENDPATH**/ ?>