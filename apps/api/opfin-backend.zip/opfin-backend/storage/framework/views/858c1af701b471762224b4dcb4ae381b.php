<?php $__env->startSection('title', 'Knowledge Sources'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Knowledge Sources</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#knowledgeModal"
                onclick="openCreateModal()">+ Add New</button>
        </div>

        <table class="table table-striped" id="knowledgeTable">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $knowledge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id="<?php echo e($k->id); ?>">
                        <td><?php echo e($k->title); ?></td>
                        <td><?php echo e($k->url ?? '-'); ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="openEditModal(<?php echo e($k->id); ?>)">Edit</button>
                            <button class="btn btn-sm btn-danger"
                                onclick="deleteKnowledge(<?php echo e($k->id); ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="knowledgeModal" tabindex="-1" aria-labelledby="knowledgeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="knowledgeForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="knowledgeModalLabel">Add Knowledge</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="knowledgeId">
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="url" class="form-label">URL</label>
                            <input type="url" class="form-control" id="url" name="url">
                        </div>
                        <div class="mb-3">
                            <label for="content" class="form-label">Content</label>
                            <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save & Index</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        let modalEl = new bootstrap.Modal(document.getElementById('knowledgeModal'));

        function openCreateModal() {
            document.getElementById('knowledgeForm').reset();
            document.getElementById('knowledgeId').value = '';
            document.getElementById('knowledgeModalLabel').innerText = 'Add Knowledge';
            modalEl.show();
        }

        function openEditModal(id) {
            fetch(`/knowledge/${id}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('knowledgeId').value = data.id;
                    document.getElementById('title').value = data.title;
                    document.getElementById('url').value = data.url;
                    document.getElementById('content').value = data.content;
                    document.getElementById('knowledgeModalLabel').innerText = 'Edit Knowledge';
                    modalEl.show();
                });
        }

        document.getElementById('knowledgeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            let id = document.getElementById('knowledgeId').value;
            let method = id ? 'PUT' : 'POST';
            let url = id ? `/knowledge/${id}` : `/knowledge`;
            let formData = {
                title: document.getElementById('title').value,
                content: document.getElementById('content').value,
                url: document.getElementById('url').value,
                _token: '<?php echo e(csrf_token()); ?>'
            };

            fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                })
                .then(res => res.json())
                .then(data => {
                    location.reload(); // reload table with updated data
                })
                .catch(err => console.error(err));
        });

        function deleteKnowledge(id) {
            if (!confirm('Are you sure you want to delete this knowledge?')) return;
            fetch(`/knowledge/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            }).then(res => {
                if (res.ok) location.reload();
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/opfin-api/resources/views/knowledge/index.blade.php ENDPATH**/ ?>